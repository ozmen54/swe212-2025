#!/usr/bin/bash

docker-compose down -v
