
Warning: The stop.sh script clears the mounted volume! All data will be lost.

Database names and ports:
1) Coustomer service: 
DB name: customer_db 
Port: 33061
Username: root
Password: mysql

2) Car service: 
DB name: car_db 
Port: 33062
Username: root
Password: mysql

3) Reservation service: 
DB name: reservation_db 
Port: 33063
Username: root
Password: mysql

Client connection example from host:
 > mysql -P 33061 -h 127.0.0.1 -u root -pmysql
